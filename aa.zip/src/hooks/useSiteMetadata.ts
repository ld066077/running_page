import siteMetadata from '@/static/site-metadata';

const useSiteMetadata = () => siteMetadata;

export default useSiteMetadata;

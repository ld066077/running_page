export const yearStats = import.meta.glob('./year_*.svg', { import: 'ReactComponent' })
export const totalStat = import.meta.glob(['./github.svg', './grid.svg'], { import: 'ReactComponent' })

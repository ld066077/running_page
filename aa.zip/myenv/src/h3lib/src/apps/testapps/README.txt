H3 tests: this directory contains test programs that are invoked by CTest.
